import 'package:flutter/material.dart';
import 'package:mangr/data/data.dart';
import 'package:mangr/objects/project.dart';
import 'package:mangr/utils.dart';
import 'package:mangr/utils.dart' as prefix0;


class ProjectPage extends StatefulWidget {

  final Project project;
  final DataHelper dataHelper;

  ProjectPage({Key key,@required this.project,@required this.dataHelper}) : super(key: key);

  @override
  _ProjectPageState createState() => _ProjectPageState();
}

class _ProjectPageState extends State<ProjectPage> {

  bool snapToEnd = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: getAppBar(widget.project.name),
      body: Column(
        children: <Widget>[
          
          Padding(
            padding: EdgeInsets.only(top: 20,bottom: 10),
            child: getText(widget.project.description),
          ),

          getButton(
            variant: 2,
            text: 'Curent date: ${getDateFormat().format(widget.project.deadline)}',
            onPressed: (){
              prefix0.showDistivityDatePicker(
                context: context,
                onDateSelected: (date){
                  setState(() {
                   widget.project.deadline=date;
                   widget.dataHelper.addProject(true,product: widget.project);
                  });
                }
              );
            }
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(widget.project.checklist.length, (index){

              List<String> strings = getCheckName(index).split('.');

              return ListTile(
                leading: getFlareCheckbox(widget.project.checklist[index], snapToEnd,
                  onCallbackCompleted: (checked){
                    setState(() {
                      print('got to oncallbackcompleted setstate');
                      widget.dataHelper.addProject(true,product: widget.project); 
                    });
                  },
                  onTap: (){
                    setState(() {
                     snapToEnd=false;
                     widget.project.checklist[index] = !widget.project.checklist[index]; 
                    });
                  },
                  ),
                title: getText(strings[0],crossed: widget.project.checklist[index]),
                subtitle:strings.length!=1?getText(strings[1],textType: TextType.textTypeSubNormal):null,
              );
            }),
          )
        ],
      ),
    );
  }


  String getCheckName(int index){
    switch(index){
      case ProjectObjectHelper.todo_populate_todolist: return 'Populate your todolist with actions';break;
      case ProjectObjectHelper.todo_prioritize: return 'Prioritize your todos.Remember, effectiveness beats productivity';break;
      case ProjectObjectHelper.set_deadlines: return 'Set deadlines to this project';break;
      case ProjectObjectHelper.release_demo: return 'Release the product to the public'; break;
      case ProjectObjectHelper.gain_feedback: return 'Gain feedback from the users and meetings.See what you did right,wrong and what you can improve on';break;
      case ProjectObjectHelper.complete_tasks: return 'Complete tasks'; break;
      default: return 'dlkdfjldf'; break;
    }
  }
}