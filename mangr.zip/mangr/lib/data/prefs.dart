


import 'package:shared_preferences/shared_preferences.dart';

class Prefs{

  static Prefs _instance;
  static Future<Prefs> getInstance()async{

    if(_instance.sharedPreferences==null){
      _instance.sharedPreferences= await SharedPreferences.getInstance();
    }

    return _instance;

  }


  SharedPreferences sharedPreferences;


}