import 'package:flutter/material.dart';
import 'package:mangr/utils.dart';



class SettingsPage extends StatefulWidget {
  SettingsPage({Key key}) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: getAppBar('Settings',backEnabled: true,context: context),
      body: Column(
        children: <Widget>[
          Center(child: getText('More to come.....'),)
        ],
      ),
    );
  }
}