import 'package:flutter/material.dart';
import 'package:mangr/data/data.dart';
import 'package:mangr/icon_pack_icons.dart';
import 'package:mangr/utils.dart';
import 'package:mangr/widgets/widget_parts/tab_layout.dart';


class BudgetPage extends StatefulWidget {

  final DataHelper dataHelper;

  BudgetPage({Key key,@required this.dataHelper}) : super(key: key);

  @override
  BudgetPageState createState() => BudgetPageState();
}

class BudgetPageState extends State<BudgetPage> {


  int totalRevenue ;
  int revenuePerMonth;
  int expensesPerMonth;


  @override
  void initState() { 

    if(totalRevenue==null){
      totalRevenue=widget.dataHelper.getTotalRevenue();
    }

    if(revenuePerMonth==null){
      revenuePerMonth = widget.dataHelper.getRevenuePerMonth();
    }

    if(expensesPerMonth == null){
      expensesPerMonth = widget.dataHelper.getExpensesPerMonth();
    }


    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: getAppBar('Budgeting',backEnabled: true,context: context),
      body: Column(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(top: 15,bottom: 10),
            child: getText('Total revenue',textType: TextType.textTypeSubtitle),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(left: 10),
                child: getText('$totalRevenue\$',textType: TextType.textTypeSubtitle),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 20,left: 10),
                child: IconButton(
                  icon: Icon(IconPack.edit,size: 15,),
                  onPressed: (){
                    showEditTotalRevenueBottomSheet(
                      context: context,
                      dataHelper: widget.dataHelper,
                      updateJson: (){updateJson();},
                    );
                  },
                ),
              ),
            ],
          ),

          Padding(
            padding: EdgeInsets.only(top: 15,bottom: 10),
            child: getText('Revenue per month',textType: TextType.textTypeSubtitle),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(left: 10),
                child: getText('$revenuePerMonth\$',textType: TextType.textTypeSubtitle),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 20,left: 10),
                child: IconButton(
                  icon: Icon(IconPack.edit,size: 15,),
                  onPressed: (){
                    BudgetPageState.showEditExpensesRevenuePerMonthBottomSheet(
                                                expensesNotRevenue: false,
                                                context: context,
                                                updateJson: (){updateJson();},
                                                dataHelper: widget.dataHelper);
                  },
                ),
              ),
            ],
          ),


          Padding(
            padding: EdgeInsets.only(top: 15,bottom: 10),
            child: getText('Expeneses per month',textType: TextType.textTypeSubtitle),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(left: 10),
                child: getText('$expensesPerMonth\$',textType: TextType.textTypeSubtitle),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 20,left: 10),
                child: IconButton(
                  icon: Icon(IconPack.edit,size: 15,),
                  onPressed: (){
                    BudgetPageState.showEditExpensesRevenuePerMonthBottomSheet(
                                                expensesNotRevenue: true,
                                                context: context,
                                                updateJson: (){updateJson();},
                                                dataHelper: widget.dataHelper);
                  },
                ),
              )
            ],
          ),
        ],
      ),
    );
  }


  static showEditTotalRevenueBottomSheet({@required DataHelper dataHelper,@required BuildContext context,@required Function updateJson}){

    int tabLayoutPosition = 0;  
    TextEditingController valueController = TextEditingController();

    showDistivityModalBottomSheet(context, Column(

      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.all(10),
          child: TabLayout(
            entries: ['Add','Remove'],
            onSelectedPos: (pos){
              tabLayoutPosition=pos;
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              getTextField(hint: "Enter value here",textEditingController: valueController,
                focus: true,width: 300,textInputType: TextInputType.number),
              IconButton(
                icon: Icon(Icons.send),
                onPressed: (){
                  int newValue = 0;
                  if(tabLayoutPosition==0){
                    newValue = int.parse(valueController.text) + dataHelper.getTotalRevenue();
                  }else{
                    newValue = dataHelper.getTotalRevenue() - int.parse(valueController.text);
                  }

                  dataHelper.setTotalRevenue(newValue);
                  Navigator.pop(context);
                  updateJson();
                },
              ),
            ],
          ),
        ),


      ],


    ));

  }





  static showEditExpensesRevenuePerMonthBottomSheet({@required bool expensesNotRevenue,@required DataHelper dataHelper,@required BuildContext context,@required Function updateJson}){

    TextEditingController textEditingController = TextEditingController();

    showDistivityModalBottomSheet(context, Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(left: 10),
          child: getTextField(
            focus: true,
            textEditingController: textEditingController,
            hint: expensesNotRevenue?"Expenses Per Month:" : "Revenue Per Month",
            textInputType: TextInputType.number,
            width: 300
          ),
        ),
        IconButton(
          icon: Icon(IconPack.send),
          onPressed: (){
            if(expensesNotRevenue){
              dataHelper.setExpensesPerMonth(int.parse(textEditingController.text));
            }else{
              dataHelper.setRevenuePerMonth(int.parse(textEditingController.text));
            }
            Navigator.pop(context);
            updateJson();
          },
        ),
      ],
    ));

  }

  void updateJson() {
    setState(() {
     totalRevenue=widget.dataHelper.getTotalRevenue();
     revenuePerMonth=widget.dataHelper.getRevenuePerMonth();
     expensesPerMonth=widget.dataHelper.getExpensesPerMonth(); 
    });

  }
}