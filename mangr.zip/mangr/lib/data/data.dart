
import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:mangr/objects/date_value_object.dart';
import 'package:mangr/objects/goal.dart';
import 'package:mangr/objects/project.dart';
import 'package:mangr/utils.dart';
import 'package:mangr/widgets/pages/setup_page.dart';
import 'package:path/path.dart';
import "package:path_provider/path_provider.dart";

class DataHelper{


  Map<String,dynamic> business;
  Directory localDirectory;
  Function onDataUpdated;

  DataHelper({this.onDataUpdated});
  static DataHelper _dataHelper;
  static Future<DataHelper> getInstance(BuildContext context,{Function onDataUpdated})async{

    if(_dataHelper==null){
      _dataHelper=DataHelper();
    }

    if(_dataHelper.localDirectory==null){
      _dataHelper.localDirectory =await getApplicationDocumentsDirectory();
    }

    if(onDataUpdated!=null){
      _dataHelper.onDataUpdated=onDataUpdated;
    }

    File file = File(join(_dataHelper.localDirectory.path,"business.json"));

    if(!await file.exists()){
      await file.create();
      file.writeAsString(jsonEncode({'name':'Your business','id':0}));
      _dataHelper.business = jsonDecode(await file.readAsString());
    }else{
      _dataHelper.business = jsonDecode((await file.readAsString())??'  ');
    }

    if(_dataHelper.getBusinessName()=='ls--'){
      launchPage(context,SetupPage(dataHelper: _dataHelper,));
    }

    return _dataHelper;
  }



  
/////////goals
addGoal(bool update,{@required Goal goal}){

    List goals = business[_ConstantsHelpers.goals]??List();
    if(update){
      for(int i = 0 ; i < goals.length ; i++){
        if(goals[i]['id']==goal.id){
          goals[i]=goal.toMap();
        }
      }
    }else{
      goals.add(goal.toMap());
    }

    business[_ConstantsHelpers.goals]=goals;
    saveJson();

  }

  List<Goal> getGoals(){

    List<Goal> goals = List();

    List mappedGoals = business[_ConstantsHelpers.goals]??List();

    if(mappedGoals==null){
      return List();
    }

    mappedGoals.forEach((f){
      goals.add(Goal.fromMap(f));
    });

    return goals;
  }


  deleteGoal(int goalId){

    List<Map<String,dynamic>> goalsMap = business[_ConstantsHelpers.goals];

    for(int i = 0 ; i<goalsMap.length;i++){
      if(goalsMap[i]['id']==goalId){
        goalsMap.removeAt(i);
        business[_ConstantsHelpers.goals]=goalsMap;
        saveJson();
      }
    }


  }
////////




  //business name

  setBusinessName(String name){
    business['bsname']=name;
    saveJson();
  }

  getBusinessName(){
    return business['bsname']??'ls--';
  }




  //products
  addProject(bool update,{@required Project product}){

    print('print set in add project');

    List products = business[_ConstantsHelpers.products]??List();


    if(update){
      for(int i = 0 ; i< products.length; i++){
        Project curentProject = Project.fromMap(products[i]);
        if(product.id==curentProject.id){
          products[i]=product.toMap();
        } 
      }
    }else{
      products.add(product.toMap());
    }


    
    business[_ConstantsHelpers.products]=products;
    saveJson();

  }

  List<Project> getProjects(){

    List products = business[_ConstantsHelpers.products];


    if(products ==null){
      return List();
    }else{

      List<Project> toReturn = List();

      products.forEach((product){
        toReturn.add(Project.fromMap(product));
      });

      return toReturn;
    }


  }


  deleteProject(int id){

    List products = business[_ConstantsHelpers.products];

    for(int i = 0 ; i<products.length;i++){
      if(products[i]['id']==id){
        products.removeAt(i);
        business[_ConstantsHelpers.products]=products;
        saveJson();
      }
    }


  }
  ///



  getIdCount(){
    int id= business[_ConstantsHelpers.id]??-1;


    business[_ConstantsHelpers.id]= id+1;
    saveJson();


    return id;
  }


  //marketing
  setMarketingStrategy(List<int> marketingStrategy){
    business[_ConstantsHelpers.marketingStrategy] = marketingStrategy;
    saveJson();
  }

  List<int> getMarketingStrategies(){
    return business[_ConstantsHelpers.marketingStrategy]?? List();
  }
  //

  //revenue strategy
  setRevenueStrategy(List<int> revenueStrategy){
    business[_ConstantsHelpers.revenueStrategy] = revenueStrategy;
    saveJson();
  }

  List<int>getRevenueStrategy(){
    return business[_ConstantsHelpers.revenueStrategy]??List();
  }
  //

  //guidance
  setIsGuidance(bool guidance){
    business[_ConstantsHelpers.guidance] = guidance;
    saveJson();
  }

  bool getIsGuidance(){
    return business[_ConstantsHelpers.guidance]??false;
  }  
  //

  //more_than_1_product
  setHasMoreThan1Product(bool hasMoreThan1Product){
    business[_ConstantsHelpers.moreThan1Product] = hasMoreThan1Product;
    saveJson();
  }

  bool getHasMoreThan1Product(){
    return business[_ConstantsHelpers.moreThan1Product]??false;
  }  
  //

  //b2b/b2c
  setB2bB2c(bool isB2B){
    business[_ConstantsHelpers.b2b_b2c] = isB2B;
    saveJson();
  }

  bool getIsB2b(){
    return business[_ConstantsHelpers.b2b_b2c]??false;
  }  
  //


  //organization_method
  setOrganizationMethod(int organizationMethod){
    business[_ConstantsHelpers.organizationMethod] = organizationMethod;
    saveJson();
  }

  int getOrganizationMethod(){
    return business[_ConstantsHelpers.organizationMethod]??DataConstants.org_meth_no_meth;
  }  
  //

  //niche
  setNiche(String niche){
    business[_ConstantsHelpers.niche] = niche;
    saveJson();
  }

  String getNiche(){
    return business[_ConstantsHelpers.niche]?? 'No niche';
  }  
  //


  //digital_or_phisichal
  setIsBusinessDigital(bool isDigital){
    business[_ConstantsHelpers.digital_phisichal_business] = isDigital;
    saveJson();
  }

  bool getIsBusinessDigital(){
    return business[_ConstantsHelpers.digital_phisichal_business]?? false;
  }  
  //


  //interests
  setInterest(List<int> interests){
    business[_ConstantsHelpers.interests] = interests;
    saveJson();
  }

  List getInterests(){
    return business[_ConstantsHelpers.interests]?? List;
  }  
  //


   //people
  setNrOfPeople(int people){
    business[_ConstantsHelpers.people] = people;
    saveJson();
  }

  int getPeople(){
    return business[_ConstantsHelpers.people]??1;
  }  
  //


  List<DateValueObject> getRevenueHistory(){

    List mapRH = business[_ConstantsHelpers.revenueHistory];

    List<DateValueObject> rh = List();

    if(mapRH == null){
      return rh;
    }

    mapRH.forEach((i){
      rh.add(DateValueObject.fromMap(i));
    });

    return rh;
  }


  List<DateValueObject> getRevenuePerMonthHistory(){

    List mapRH = business[_ConstantsHelpers.revenuePerMonthHistory]??List();

    List<DateValueObject> rh = List();

    mapRH.forEach((i){
      rh.add(DateValueObject.fromMap(i));
    });

    return rh;
  }


  List<DateValueObject> getExpensesPerMonthHistory(){

    List mapRH = business[_ConstantsHelpers.expensesPerMonthHistory]??List();

    List<DateValueObject> rh = List();

    mapRH.forEach((i){
      rh.add(DateValueObject.fromMap(i));
    });

    return rh;
  }


  /////////revenue related
  setRevenuePerMonth(int rpm){
    business[_ConstantsHelpers.revenuePerMonth]=rpm;


    List revenuePerMonthHistory =business[_ConstantsHelpers.revenuePerMonthHistory]?? List();

    revenuePerMonthHistory.add(DateValueObject(DateTime.now(),rpm).toMap());

    business[_ConstantsHelpers.revenuePerMonthHistory]=revenuePerMonthHistory;

    saveJson();
  }
  int getRevenuePerMonth(){
    return business[_ConstantsHelpers.revenuePerMonth]??0;
  }

  setExpensesPerMonth(int epm){
    business[_ConstantsHelpers.expensesPerMonth]=epm;


    List expensesPerMonthHistory = business[_ConstantsHelpers.expensesPerMonthHistory]??List();

    expensesPerMonthHistory.add(DateValueObject(DateTime.now(),epm).toMap());

    business[_ConstantsHelpers.expensesPerMonthHistory]=expensesPerMonthHistory;


    saveJson();
  }
  int getExpensesPerMonth(){
    return business[_ConstantsHelpers.expensesPerMonth]??1;
  }

  setTotalRevenue(int tr,{bool update}){

    if(update==null){
      update=true;
    }

    business[_ConstantsHelpers.totalRevenue]=tr;

    List<Map<String,dynamic>> revenueHistory = List();
    List maprh =business[_ConstantsHelpers.revenueHistory];
    if(maprh!=null){
      maprh.forEach((item){
        revenueHistory.add(item);
      });
    }

    revenueHistory.add(DateValueObject(DateTime.now(),tr).toMap());

    business[_ConstantsHelpers.revenueHistory]=revenueHistory;


    if(update){
      saveJson();
    }
  }
  int getTotalRevenue(){
    return business[_ConstantsHelpers.totalRevenue]??0;
  }

  setPayDay(DateTime payday){
     business[_ConstantsHelpers.payday]=getDateFormat().format(payday);
     saveJson();
  }
  DateTime getPayDay(){

    String paydayString =business[_ConstantsHelpers.payday];

    if(paydayString==null){
      int days = DateTime.now().day;

      paydayString=getDateFormat().format(DateTime.now().subtract(Duration(days:days-1 )));
      setPayDay(getDateFormat().parse(paydayString));
    }

    DateTime payday  = getDateFormat().parse(paydayString);
    return payday;
  }
  /////revenuerelated
  


  saveJson()async{
    await File(join(localDirectory.path,"business.json")).writeAsString(jsonEncode(business));
    onDataUpdated();
  }

  deleteBusiness()async{
    await File(join(localDirectory.path,"business.json")).writeAsString('  ');
    onDataUpdated();
  }


}

class _ConstantsHelpers{

  static const String marketingStrategy = "marketing strategy";
  static const String revenueStrategy = "rev strategy";
  static const String interests = "interests";
  static const String guidance = "guidance";
  static const String moreThan1Product = "mt1p";
  static const String b2b_b2c = "b2bb2c";
  static const String organizationMethod = "orgmeth";
  static const String niche = "niceh";
  static const String digital_phisichal_business = "dpb";
  static const String people = "peopel";
  static const String id = "id";

  static const String goals = "goals";

  static const String singleProductName = "spn";
  static const String products = "products";
  static const String productName = "productname";
  static const String productTasks = "producttasks";


  static const String revenueHistory = "revenue history";
  static const String revenuePerMonth = "revenue per month";
  static const String expensesPerMonth = "expenses per month";
  static const String payday = "expenses revenue dat";
  static const String totalRevenue = "total revenue";

  static const String revenuePerMonthHistory = "rpmh";
  static const String expensesPerMonthHistory = 'epmh';


}

class DataConstants{

  static const int marketing_strategy_ads = 001;
  static const int marketing_strategy_influencers = 0101;
  static const int marketing_strategy_instagram = 223001;
  static const int marketing_strategy_facebook = 02101;
  static const int marketing_strategy_tweeter = 003221;
  static const int marketing_strategy_linkedin = 01111101;
  static const int marketing_strategy_youtube = 0111111301;
  static const int marketing_strategy_blog = 011111111101;
  static const int marketing_strategy_guestposting = 77001;
  static const int marketing_strategy_forums = 09901;


  static const int revenue_strategy_paid_product = 1;
  static const int revenue_strategy_subscription_base_product = 1112;
  static const int revenue_strategy_ads_affiliate_marketing = 15;
  static const int revenue_strategy_no_profit = 17;


  static const int interest_product_design_personas_ui_ux = 101009901;
  static const int interest_revenue_expenses = 1011111009901;
  static const int interest_product_management = 2101009901;
  static const int interest_marketing_content_creation = 10441009901;


  static const int org_meth_plblpl = 0;
  static const int org_meth_version = 1;
  static const int org_meth_no_meth = 2;


  static const int people_1 = 0;
  static const int people_less_5 = 1;
  static const int people_more_5 = 2;
  static const int people_10plus = 3;


}
