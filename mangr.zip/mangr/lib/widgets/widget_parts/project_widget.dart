import 'package:flutter/material.dart';
import 'package:mangr/data/data.dart';
import 'package:mangr/objects/project.dart';
import 'package:mangr/widgets/pages/project_page.dart';

import '../../icon_pack_icons.dart';
import '../../utils.dart';

class ProjectWidget extends StatefulWidget {

  final Project project;
  final DataHelper dataHelper;
  final Function() onEditPressed;
  final Function onItemDeleted;

  ProjectWidget({Key key,@required this.project,@required this.dataHelper,this.onEditPressed,this.onItemDeleted}) : super(key: key);

  @override
  _ProjectWidgetState createState() => _ProjectWidgetState();
}

class _ProjectWidgetState extends State<ProjectWidget> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
            onTap: (){
              launchPage(context, ProjectPage(dataHelper: widget.dataHelper,project: widget.project,));
            },
            title: getText(widget.project.name),
            subtitle: LinearProgressIndicator(
              value: getProgress(widget.project),
            ),
            trailing: Visibility(
              visible: widget.onEditPressed!=null,
              child: PopupMenuButton(
                icon: Icon(IconPack.dots_vertical),
                itemBuilder: (ctx){
                  return <PopupMenuItem>[
                    getPopupMenuItem(value: 1,name: 'EditProject',iconData: IconPack.edit),
                    getPopupMenuItem(value: 0,name: 'Delete project',iconData: IconPack.trash),
                  ];
                },
                onSelected: (value){
                  switch(value){
                    case 0 : widget.dataHelper.deleteProject(widget.project.id);widget.onItemDeleted(); break;
                    case 1 : widget.onEditPressed(); break;
                  }
                },
              ),
            ),
          );
  }

  double getProgress(Project curentProject){
    double progress = 0;

    curentProject.checklist.forEach((check){
      if(check){
        progress = progress + 0.165;
      }
    });

    return progress;
  }
}