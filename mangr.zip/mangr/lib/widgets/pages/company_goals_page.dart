import 'package:flutter/material.dart';
import 'package:mangr/data/data.dart';
import 'package:mangr/icon_pack_icons.dart';
import 'package:mangr/objects/goal.dart';
import 'package:mangr/utils.dart';
import 'package:mangr/utils.dart' as prefix0;
import 'package:mangr/widgets/widget_parts/goal_widget.dart';


class CompanyGoalsPage extends StatefulWidget {

  final DataHelper dataHelper;

  CompanyGoalsPage({Key key,@required this.dataHelper}) : super(key: key);

  @override
  _CompanyGoalsPageState createState() => _CompanyGoalsPageState();
}

class _CompanyGoalsPageState extends State<CompanyGoalsPage> {


  List<Goal> companyGoals ;

  @override
  void initState() {
    if(companyGoals==null){
      companyGoals=widget.dataHelper.getGoals();
    }
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.builder(
        itemCount: companyGoals.length,
        itemBuilder: (ctx,index){
          return GoalWidget(
            goal: companyGoals[index],
            onTap: (){
              showAddGoalBottomSheet(goal: companyGoals[index]);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        label: getText('Add goal',color: Colors.white),
        icon: Icon(IconPack.add),
        onPressed: (){
          showAddGoalBottomSheet();
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      appBar: getAppBar('Company Goals',context: context,backEnabled: true),
    );
  }

  showAddGoalBottomSheet({Goal goal}){

    TextEditingController nameTextEditingController = TextEditingController();
    TextEditingController descriptionTextEditingController = TextEditingController();
    DateTime duedate = DateTime(2019);
    int id;


    if(goal!=null){
      nameTextEditingController.text = goal.name;
      descriptionTextEditingController.text = goal.description;
      duedate = goal.dueDate;
      id= goal.id;
    }else{
      id = widget.dataHelper.getIdCount();
    }

    showDistivityModalBottomSheet(context, Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            getTextField(
            textEditingController: nameTextEditingController,
            textInputType: TextInputType.text,
            width: 300,
            focus: true,
            hint: 'Enter your goal here'
              ),
            IconButton(
              icon: Icon(IconPack.send),
              onPressed: (){
                widget.dataHelper.addGoal(goal!=null,goal: Goal(
                  description: descriptionTextEditingController.text,
                  dueDate: duedate,
                  id: id,
                  name: nameTextEditingController.text
                ));
                Navigator.pop(context);
                setChanges();
              },
            )
          ],
        ),
        getTextField(
          textEditingController: descriptionTextEditingController,
          textInputType: TextInputType.text,
          width: 350,
          focus: false,
          hint: 'Describe your goal here',
          variant: 2,
        ),
        getButton(
          onPressed: (){
           prefix0.showDistivityDatePicker(
             context: context,
             onDateSelected: (date){
               duedate = date;
             }
           );
          },
          text: 'Pick date',
          variant: 2,
        )
      ],
    ));
  }

  setChanges(){
    setState(() {
     companyGoals = widget.dataHelper.getGoals(); 
    });
  }
}