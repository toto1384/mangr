
import 'package:flutter/material.dart';
import 'package:launch_review/launch_review.dart';
import 'package:mangr/icon_pack_icons.dart';
import 'package:mangr/objects/goal.dart';
import 'package:mangr/objects/project.dart';
import 'package:mangr/utils.dart';
import 'package:mangr/widgets/pages/budget_page.dart';
import 'package:mangr/widgets/pages/company_goals_page.dart';
import 'package:mangr/widgets/pages/projects_page.dart';
import 'package:mangr/widgets/pages/settings_page.dart';
import 'package:mangr/widgets/pages/setup_page.dart';
import 'package:mangr/widgets/pages/stats_page.dart';
import 'package:mangr/widgets/widget_parts/goal_widget.dart';
import 'package:mangr/widgets/widget_parts/project_widget.dart';

import 'data/data.dart';
 
void main() => runApp(MyApp());
 
class MyApp extends StatelessWidget {

  static bool isDarkMode = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mangr',
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}


class HomePage extends StatefulWidget {

  final bool updateDb;


  HomePage({Key key,this.updateDb}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {


  DataHelper dataHelper;

  List<Goal> companyGoals;
  List<Project> projects;


  Future<bool> init()async{
    if(widget.updateDb??false||dataHelper==null){
      dataHelper = await DataHelper.getInstance(context,onDataUpdated: (){
        updateJson();
      });
    }

    if(companyGoals==null){
      companyGoals = dataHelper.getGoals();
    }

    if(projects==null){
      projects = dataHelper.getProjects();
    }

    if(getDateFormat().format(dataHelper.getPayDay())==getDateFormat().format(DateTime.now().subtract(Duration(days: 30)))){
      int totalRevenue = dataHelper.getTotalRevenue();

      totalRevenue = totalRevenue - dataHelper.getExpensesPerMonth();
      totalRevenue = totalRevenue + dataHelper.getRevenuePerMonth();

      dataHelper.setTotalRevenue(totalRevenue,update: false);
    }
    return true;
    
  }



  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: init(),
      builder: (ctx,snap){
        return snap.hasData?Scaffold(
          bottomNavigationBar: BottomAppBar(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                IconButton(
                  icon: Icon(IconPack.menu_line),
                  onPressed: (){showMenuBottomSheet();},
                ),
                IconButton(
                  icon: Icon(IconPack.dots_vertical),
                  onPressed: (){showMoreBottomSheet();},
                ),
              ],
            ),
          ),
          body: snap.hasData? ListView(
            children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(left: 15,right: 15,top: 23,bottom: 10),
                    child: Card(
                      shape: getShape(),
                      elevation: 10,
                      child: InkWell(
                        onTap: (){
                          launchPage(context, BudgetPage(dataHelper: dataHelper,));
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      getText("Total Revenue",textType: TextType.textTypeSubtitle),
                                      Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          getText(dataHelper.getTotalRevenue().toString(),textType: TextType.textTypeTitle),
                                          IconButton(
                                            icon: Icon(IconPack.edit,size: 15,),
                                            onPressed: (){
                                              BudgetPageState.showEditTotalRevenueBottomSheet(
                                                context: context,
                                                dataHelper: dataHelper,
                                                updateJson: (){
                                                  updateJson();
                                                }
                                              );
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                              ),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      getText("Revenue Per Month",textType: TextType.textTypeNormal),
                                      Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          getText(dataHelper.getRevenuePerMonth().toString(),textType: TextType.textTypeSubtitle),
                                          IconButton(
                                            icon:  Icon(IconPack.edit,size: 15,),
                                            onPressed: (){
                                               BudgetPageState.showEditExpensesRevenuePerMonthBottomSheet(
                                                expensesNotRevenue: false,
                                                context: context,
                                                updateJson: (){updateJson();},
                                                dataHelper: dataHelper);
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  getSkeletonView(3, 30),
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      getText("Expenses Per Month",textType: TextType.textTypeNormal),
                                      Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          getText(dataHelper.getExpensesPerMonth().toString(),textType: TextType.textTypeSubtitle),
                                          IconButton(
                                            icon:  Icon(IconPack.edit,size: 15,),
                                            onPressed: (){
                                              BudgetPageState.showEditExpensesRevenuePerMonthBottomSheet(
                                                expensesNotRevenue: true,
                                                context: context,
                                                updateJson: (){updateJson();},
                                                dataHelper: dataHelper);
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              // Padding(
                              //   padding: EdgeInsets.all(10),
                              //   child: getText("Payday: ${dataHelper.getPayDay()}"),
                              // ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(
                      children: <Widget>[
                        InkWell(
                          onTap: (){launchPage(context, StatsPage(dataHelper: dataHelper,));},
                          child: getText("Stats",textType: TextType.textTypeSubtitle),
                        ),
                        IconButton(
                          icon: Icon(IconPack.expand_icon,size: 15,),
                          onPressed: (){
                            launchPage(context, StatsPage(dataHelper: dataHelper,));
                          },
                        )
                      ],
                    ),
                  ),
                  
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Container(
                      width: 250,
                      height: 250,
                      child: getChart(dataHelper.getRevenueHistory()),
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.only(left: 10,top: 25,bottom: 15),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        InkWell(
                          onTap: (){launchPage(context, CompanyGoalsPage(dataHelper: dataHelper,));},
                          child: getText("Company Goals",textType: TextType.textTypeSubtitle),
                        ),
                        IconButton(
                          icon: Icon(IconPack.expand_icon,size: 15,),
                          onPressed: (){
                            launchPage(context, CompanyGoalsPage(dataHelper: dataHelper,));
                          },
                        )
                      ],
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: getPGList(false),
                  ),


                
                  Padding(
                    padding: EdgeInsets.only(left: 10,top: 25,bottom: 15),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        InkWell(
                          onTap: (){launchPage(context, ProjectsPage(dataHelper: dataHelper,));},
                          child: getText("Projects",textType: TextType.textTypeSubtitle),
                        ),
                        IconButton(
                          icon: Icon(IconPack.expand_icon,size: 15,),
                          onPressed: (){
                            launchPage(context, ProjectsPage(dataHelper: dataHelper,));
                          },
                        )
                      ],
                    ),
                  ),
                  Column(

                    mainAxisSize: MainAxisSize.min,
                    children: getPGList(true),
                  ),
            ],
          ):Column(
            //skeleton view
          ),
            appBar: getAppBar(dataHelper.getBusinessName()),
        ):Center(
          child: Image.asset(AssetsPath.appIcon),
        );
      },
    );
  }


  updateJson(){
    setState(() {
     companyGoals=dataHelper.getGoals();
     projects = dataHelper.getProjects();
    });
  }

  showMoreBottomSheet(){

    showDistivityModalBottomSheet(context, Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[


        ListTile(
          leading: Icon(IconPack.moon),
          title: getText('Change Theme (Work in progress :( ))'),
          onTap: (){changeTheme();},
        ),

        ListTile(
          leading: Icon(IconPack.settings),
          title: getText('Settings'),
          onTap: (){
            launchPage(context, SettingsPage());
          },
        ),

        ListTile(
          leading: Icon(IconPack.star),
          title: getText('Rate'),
          onTap: (){
            LaunchReview.launch();
          },
        ),
        

        ListTile(
          leading: Icon(IconPack.feedback),
          title: getText('Send feedback'),
          onTap: (){
            showFeedbackBottomSheet(context);
          },
        ),


        ListTile(
          leading: Icon(IconPack.trash,color: MyColors.color_red,),
          title: getText('Delete business',color: MyColors.color_red),
          onTap: (){
            dataHelper.deleteBusiness();
            launchPage(context, SetupPage(dataHelper: dataHelper,));
          },
        ),

        Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 15,bottom: 5),
              child: getText('Mangr- beta 0.1(holy s*it that\'s buggy)',maxLines: 2),
            ),
          ],
        ),
        
      ],
    ));
  }

  showMenuBottomSheet(){
    showDistivityModalBottomSheet(context, Column(
      children: <Widget>[





        ListTile(
          leading: Container(width: 30,height: 30,child: Center(child: Icon(IconPack.money_icon,size: 20,color: MyColors.color_black_darker,),),
            decoration: BoxDecoration(color: MyColors.color_secondary,borderRadius: BorderRadius.circular(30)),),
          title: getText('Budgeting'),
          onTap: (){
            launchPage(context, BudgetPage(dataHelper: dataHelper,));
          },
        ),


        ListTile(
          leading: Container(width: 30,height: 30,child: Center(child: Icon(IconPack.chart,size: 20,color: MyColors.color_black_darker,)),
            decoration: BoxDecoration(color: MyColors.color_secondary,borderRadius: BorderRadius.circular(30))),
          title: getText('Statistics'),
          onTap: (){
            launchPage(context, StatsPage(dataHelper: dataHelper,));
          },
        ),


        ListTile(
          leading: Container(width: 30,height: 30,child: Center(child: Icon(IconPack.goal,size: 20,color: MyColors.color_black_darker,)),
            decoration: BoxDecoration(color: MyColors.color_secondary,borderRadius: BorderRadius.circular(30))),
          title: getText('Company goals'),
          onTap: (){
            launchPage(context, CompanyGoalsPage(dataHelper: dataHelper,));
          },
        ),



         ListTile(
          leading: Container(width: 30,height: 30,child: Center(child: Icon(IconPack.todo,size: 20,color: MyColors.color_black_darker,)),
            decoration: BoxDecoration(color: MyColors.color_secondary,borderRadius: BorderRadius.circular(30))),
          title: getText('Projects'),
          onTap: (){
            launchPage(context, ProjectsPage(dataHelper: dataHelper,));
          },
        ),

      ],
    ));
  }

  void changeTheme() {}

  List<Widget> getPGList(bool isProjects) {

    int length;

    if(isProjects){

      length=projects.length>=5?6:projects.length;

      return List<Widget>.generate(length, (index){
        return index==5?getButton(variant: 2,text: 'More..',onPressed: (){launchPage(context, ProjectsPage(dataHelper: dataHelper,));}):
          ProjectWidget(dataHelper: dataHelper,project: projects[index],);
      });

    }else{

      length=companyGoals.length>=5?6:companyGoals.length;


    return List<Widget>.generate(length, (index){

      return index==5?getButton(variant: 2,text: 'More...',onPressed: (){launchPage(context, CompanyGoalsPage(dataHelper: dataHelper,));}):
        GoalWidget(goal: companyGoals[index],);

    });
    }


  }


}
