
import 'package:flutter/material.dart';
import 'package:mangr/data/data.dart';
import 'package:mangr/widgets/widget_parts/radio_group.dart';

import '../../main.dart';
import '../../utils.dart';

class SetupPage extends StatefulWidget {

  final DataHelper dataHelper;

  SetupPage({Key key,@required this.dataHelper}) : super(key: key);

  @override
  _SetupPageState createState() => _SetupPageState();
}

class _SetupPageState extends State<SetupPage> {

  int qIndex = 0;
  Function onContinuePressed;

  TextEditingController bsnameEditingController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //  body: Column(
      //    crossAxisAlignment: CrossAxisAlignment.center,
      //    children: <Widget>[
      //      Padding(
      //        padding: const EdgeInsets.all(10),
      //        child: getText(QuestionWidget.getQuestionName(qIndex),textType: TextType.textTypeTitle),
      //      ),
      //      Padding(
      //        padding: const EdgeInsets.only(bottom: 20,top: 30,left: 10,right: 10),
      //        child: QuestionWidget(
      //          dataHelper: widget.dataHelper,
      //          index: qIndex,
      //          onCriteriaSelected: (){
      //            setState(() {
      //             qIndex++; 
      //            });
      //          },
      //          setOnContinuePressed: (onContinuePr){
      //            this.onContinuePressed=onContinuePr;
      //          },
      //        ),
      //      ),
      //    ],
      //  ),

       body: Center(
         child: Column(
           mainAxisSize: MainAxisSize.min,
           children: <Widget>[
             getText('Business name:',textType: TextType.textTypeSubtitle),
             Padding(
               padding: EdgeInsets.only(top: 20),
               child: getTextField(textEditingController: bsnameEditingController,textInputType: TextInputType.text,width: 300,focus: true,
                hint: 'Enter your business name here'),
             )
           ],
         ),
       ),
       appBar: getAppBar('Setup'),
       floatingActionButton: getButton(variant: 1,
            text: "Continue",
            onPressed: (){
              widget.dataHelper.setBusinessName(bsnameEditingController.text);
              launchPage(context, HomePage(updateDb: true,));
              // onContinuePressed();
              // setState(() {
              //   if(qIndex==7){
              //     launchPage(context, HomePage());
              //   }else{
              //     qIndex++;
              //   }
              // });
            }),
    );
  }
}



class QuestionWidget extends StatefulWidget {

  final int index;
  final DataHelper dataHelper;
  final Function onCriteriaSelected;
  final Function(Function) setOnContinuePressed;
 

  static bool hasContinueOn(int index){
    return index==0||index==2||index==6||index==7;
  }

  static String getQuestionName(int index){
    switch(index){
      case 0:return "What's your interests in this company?"; break;
      case 1:return "My company is:"; break;
      case 2:return "Niche :" ; break;
      case 3:return "Company size"; break;
      case 4:return "My company is"; break;
      case 5:return "Business organization method:"; break;
      case 6:return "Revenue Method?"; break;
      case 7:return "Select marketing strategies"; break;
      default: return "Done"; break;
    }
  }


  QuestionWidget({Key key,@required this.index,@required this.dataHelper,@required this.onCriteriaSelected,@required this.setOnContinuePressed}) : super(key: key);

  @override
  _QuestionWidgetState createState() => _QuestionWidgetState();
}

class _QuestionWidgetState extends State<QuestionWidget> {

  @override
  Widget build(BuildContext context) {
    Widget child;

    switch(widget.index){
      case 0:
      List<RadioItem> items = [
        RadioItem(name:"Product design/Personas/Ui/Ux",isSelected: false ),
        RadioItem(name:"Revenue/Expenses",isSelected: false ),
        RadioItem(name:"Product management",isSelected: false ),
        RadioItem(name:"Marketing/Content creation",isSelected: false ),
      ];
       return MyRadioGroup(
         isMultipleSelect: true,
         items: items,
         onItemSelected: (item,checked,newItems){
           setState(() {
            items=newItems; 
           });
           widget.setOnContinuePressed((){
             List interests = List();
             for(int i = 0; i<items.length;i++ ){
               if(items[i].isSelected==true){
                 switch(i){
                   case 0:interests.add(DataConstants.interest_product_design_personas_ui_ux);break;
                   case 1:interests.add(DataConstants.interest_revenue_expenses);break;
                   case 2:interests.add(DataConstants.interest_product_management);break;
                   case 3:interests.add(DataConstants.interest_marketing_content_creation);break;
                 }
               }
             }
             widget.dataHelper.setInterest(interests);
           });
         },
       );
       break;
      case 1:
       return MyRadioGroup(
         isMultipleSelect: false,
         items: [
           RadioItem(name:"Business to Business(B2B)" ),
           RadioItem(name:"Business to Client(B2C)" )
         ],
         onItemSelected: (item,checked,newItems){
            widget.dataHelper.setB2bB2c(item==0);
            widget.onCriteriaSelected();
         },
       );
       break;
      case 2:
       TextEditingController nicheEditingController = TextEditingController();
       widget.setOnContinuePressed( (){
         widget.dataHelper.setNiche(nicheEditingController.text);
       });
       return getTextField(
         textEditingController: nicheEditingController,
         hint: "Enter your niche here",
         textInputType: TextInputType.text,
         width: 250,
         focus: true
       );
       break;
      case 3:
       return MyRadioGroup(
         isMultipleSelect: false,
         items: [
           RadioItem(name:"Only me" ),
           RadioItem(name:"Less than 5" ),
           RadioItem(name:"More than 5" ),
           RadioItem(name:"More than 10" ),
         ],
         onItemSelected: (item,checked,newItems){
           widget.dataHelper.setNrOfPeople(item);
           widget.onCriteriaSelected();
         },
       );
       break;
      case 4:
       return MyRadioGroup(
         isMultipleSelect: false,
         items: [
           RadioItem(name:"Digital" ),
           RadioItem(name:"Phisical" ),
         ],
         onItemSelected: (item,checked,newItems){
            widget.dataHelper.setIsBusinessDigital(item==0);
            widget.onCriteriaSelected();
         },
       );
       break;
      case 5:
       return MyRadioGroup(
         isMultipleSelect: false,
         items: [
           RadioItem(name:"Prelaunch➡Betalaunch➡Postlaunch"),
           RadioItem(name:"Version based"),
           RadioItem(name:"No organization"),
         ],
         onItemSelected: (item,checked,newItems){
            widget.dataHelper.setOrganizationMethod(item);
            widget.onCriteriaSelected();
         },
       );
       break;
      case 6:
       List<RadioItem> items = [
          RadioItem(name: "Paid product",isSelected: false),
          RadioItem(name: "Subscription based product",isSelected: false),
          RadioItem(name: "Ads/affiliate marketing",isSelected: false),
          RadioItem(name: "No profit",isSelected: false),
       ];
       return MyRadioGroup(
         isMultipleSelect: true,
         items: items,
         onItemSelected: (item,checked,newItems){
           setState(() {
            items=newItems;
           });
           widget.setOnContinuePressed((){
             List revenueSources = List();
             for(int i = 0; i<items.length;i++ ){
               if(items[i].isSelected==true){
                 switch(i){
                   case 0:revenueSources.add(DataConstants.revenue_strategy_paid_product);break;
                   case 1:revenueSources.add(DataConstants.revenue_strategy_subscription_base_product);break;
                   case 2:revenueSources.add(DataConstants.revenue_strategy_ads_affiliate_marketing);break;
                   case 3:revenueSources.add(DataConstants.revenue_strategy_no_profit);break;
                 }
               }
             }
             widget.dataHelper.setRevenueStrategy(revenueSources);
           });
         },
       );
       break;
      case 7:
       List<RadioItem> items = [
        RadioItem(name: "Ads",isSelected: false),
        RadioItem(name: "Content",isSelected: false,subItems: [
          RadioItem(name: "Facebook"),
          RadioItem(name: "Instagram"),
          RadioItem(name: "Tweeter"),
          RadioItem(name: "LinkedIn"),
          RadioItem(name: "Youtube"),
          RadioItem(name: "Blogpost"),
          RadioItem(name: "Guestpost"),
        ]),
        RadioItem(name: "Influencers",isSelected: false),
       ];
       return MyRadioGroup(
         isMultipleSelect: true,
         items: items,
         onItemSelected: (item,checked,newItems){
           setState(() {
            items=newItems; 
           });
           widget.setOnContinuePressed((){
             List marketingStrategies = List();
             for(int i = 0; i<items.length;i++ ){
               if(items[i].isSelected==true){
                 switch(i){
                   case 0:marketingStrategies.add(DataConstants.marketing_strategy_ads);break;
                   case 1:break;
                   case 2:marketingStrategies.add(DataConstants.marketing_strategy_facebook);break;
                   case 3:marketingStrategies.add(DataConstants.marketing_strategy_instagram);break;
                   case 4:marketingStrategies.add(DataConstants.marketing_strategy_tweeter);break;
                   case 5:marketingStrategies.add(DataConstants.marketing_strategy_linkedin);break;
                   case 6:marketingStrategies.add(DataConstants.marketing_strategy_youtube);break;
                   case 7:marketingStrategies.add(DataConstants.marketing_strategy_blog);break;
                   case 8:marketingStrategies.add(DataConstants.marketing_strategy_guestposting);break;
                 }
               }
             }
             widget.dataHelper.setMarketingStrategy(marketingStrategies);
           });
         },
       );
       break;
    }



    return Container(
       child: child,
    );
  }
}

