import 'package:flutter/cupertino.dart';

class Todo{

  int id;
  String name;
  bool checked;


  Todo({@required this.id,@required this.name,@required this.checked});

}